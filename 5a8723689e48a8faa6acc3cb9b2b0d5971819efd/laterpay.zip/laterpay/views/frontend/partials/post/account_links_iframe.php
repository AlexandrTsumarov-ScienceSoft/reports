<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<?php do_action( 'laterpay_account_links', $laterpay['css'], $laterpay['forcelang'], $laterpay['show'], $laterpay['next'] ); ?>
