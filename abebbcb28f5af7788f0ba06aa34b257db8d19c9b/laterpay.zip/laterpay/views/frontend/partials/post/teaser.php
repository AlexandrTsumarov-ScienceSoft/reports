<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="lp_teaser-content"><?php echo $laterpay['teaser_content']; ?></div>
